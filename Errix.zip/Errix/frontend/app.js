
const API = "http://localhost:3000/api";

const codeInput = document.getElementById("codeInput");
const checkBtn = document.getElementById("checkBtn");
const status = document.getElementById("status");
const results = document.getElementById("results");
const historyBox = document.getElementById("history");

document.getElementById("sampleBtn").addEventListener("click", () => {
    codeInput.value = `public class Main {
  public static void main(String[] args) {
    int age = "20"
    System.out.println(age);
  }
}`;
});

checkBtn.addEventListener("click", checkJavaCode);

const fixBtn = document.getElementById("fixBtn");

fixBtn.addEventListener("click", fixJavaCode);


function fixJavaCode() {
    let code = codeInput.value;

    if (!code.trim()) {
        status.textContent = "Code required";
        results.textContent = "Pehle Java code paste karein.";
        return;
    }

    // Fix: int age = "20";  ->  int age = 20;
    code = code.replace(
        /(\bint\s+\w+\s*=\s*)"(-?\d+)"(\s*;?)/g,
        "$1$2;"
    );

    // Fix a missing semicolon after a simple assignment.
    code = code.replace(
        /^(\s*(?:int|String|double|float|long|boolean)\s+\w+\s*=\s*[^;\n]+?)\s*$/gm,
        "$1;"
    );

    codeInput.value = code;
    status.textContent = "Fix applied";
    results.textContent =
        "Basic fix suggest kiya gaya hai. Ab Check Java Code dabakar verify karein.";
}
document.getElementById("refreshBtn").addEventListener("click", loadHistory);

async function checkJavaCode() {
    const code = codeInput.value.trim();

    if (!code) {
        status.textContent = "Code required";
        results.textContent = "Please paste your Java code first.";
        return;
    }

    checkBtn.disabled = true;
    checkBtn.textContent = "Checking...";
    status.textContent = "Checking";
    results.textContent = "Checking Java compiler messages...";

    try {
        const response = await fetch(`${API}/check`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "Request failed");
        }

        showResults(data);
        status.textContent = data.success ? "No errors" : "Errors found";
        await loadHistory();
    } catch (error) {
        status.textContent = "Connection error";
        results.textContent =
            "Backend se connection nahi hua. Check karein ki backend aur MongoDB chal rahe hain. Details: " +
            error.message;
    } finally {
        checkBtn.disabled = false;
        checkBtn.textContent = "Check Java Code";
    }
}

function showResults(data) {
    results.replaceChildren();

    const summary = document.createElement("div");
    summary.className = "result-item";

    const heading = document.createElement("h3");
    heading.className = data.success ? "success" : "error";
    heading.textContent = data.success
        ? "Compilation successful"
        : "Compilation errors found";

    const description = document.createElement("p");
    description.textContent = data.success
        ? "Java compiler ne errors report nahi kiye. Program execute nahi hua."
        : "Neeche compiler errors aur unki beginner-friendly explanations dekhein.";

    summary.append(heading, description);
    results.appendChild(summary);

    if (data.diagnostics && data.diagnostics.length > 0) {
        data.diagnostics.forEach((item, index) => {
            const card = document.createElement("div");
            card.className = "result-item";

            const title = document.createElement("h3");
            title.textContent = `Step ${index + 1}: ${item.title}`;

            const message = document.createElement("p");
            message.textContent = item.message;

            const explanation = document.createElement("p");
            explanation.textContent = "Explanation: " + item.explanation;

            card.append(title, message, explanation);
            results.appendChild(card);
        });
    } else if (!data.success && data.compilerOutput) {
        const card = document.createElement("div");
        card.className = "result-item";

        const title = document.createElement("h3");
        title.textContent = "Compiler output";

        const output = document.createElement("pre");
        output.style.whiteSpace = "pre-wrap";
        output.textContent = data.compilerOutput;

        card.append(title, output);
        results.appendChild(card);
    }
}

async function loadHistory() {
    try {
        const response = await fetch(`${API}/history`);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || "History unavailable");
        }

        historyBox.replaceChildren();

        if (!data.history.length) {
            historyBox.textContent = "No checks saved yet.";
            return;
        }

        data.history.forEach(item => {
            const row = document.createElement("div");
            row.className = "history-row";

            const preview = document.createElement("span");
            preview.textContent = item.preview;

            const result = document.createElement("span");
            result.textContent = item.success ? "Passed" : "Errors found";

            row.append(preview, result);
            historyBox.appendChild(row);
        });
    } catch {
        historyBox.textContent =
            "History load nahi hui. Backend aur MongoDB connection check karein.";
    }
}

loadHistory();