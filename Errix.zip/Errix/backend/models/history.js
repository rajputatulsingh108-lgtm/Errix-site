
const mongoose = require("mongoose");

const historySchema = new mongoose.Schema({
    preview: {
        type: String,
        required: true,
        maxlength: 120
    },

    success: {
        type: Boolean,
        required: true
    },

    compilerOutput: {
        type: String,
        default: "",
        maxlength: 12000
    },

    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("History", historySchema);