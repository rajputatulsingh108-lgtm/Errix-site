
require("dotenv").config();

const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const { spawn } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const History = require("./models/History");

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(cors());
app.use(express.json({ limit: "40kb" }));

// Test whether the backend and database are connected.
app.get("/api/health", (req, res) => {
    res.json({
        server: "running",
        database:
            mongoose.connection.readyState === 1
                ? "connected"
                : "not connected"
    });
});

// Receive and compile Java code.
app.post("/api/check", async (req, res) => {
    const code = req.body && req.body.code;

    if (typeof code !== "string" || !code.trim()) {
        return res.status(400).json({
            error: "Please provide Java code."
        });
    }

    if (code.length > 30000) {
        return res.status(413).json({
            error: "Code is too long. Maximum 30,000 characters."
        });
    }

    // Create a temporary folder for this compilation.
    const tempDir = fs.mkdtempSync(
        path.join(os.tmpdir(), "errix-java-")
    );

    const sourcePath = path.join(tempDir, "Main.java");

    try {
        // This starter supports a single Main.java source file.
        fs.writeFileSync(sourcePath, code, "utf8");

        const result = await compileJava(sourcePath, tempDir);

        const diagnostics = result.success
            ? []
            : explainCompilerOutput(result.output);

        // Save the result in MongoDB when the database is connected.
        if (mongoose.connection.readyState === 1) {
            try {
                await History.create({
                    preview: code.replace(/\s+/g, " ").slice(0, 120),
                    success: result.success,
                    compilerOutput: result.output.slice(0, 12000)
                });
            } catch (dbError) {
                console.error("History could not be saved:", dbError.message);
            }
        }

        return res.json({
            success: result.success,
            compilerOutput: result.output.slice(0, 12000),
            diagnostics
        });
    } catch (error) {
        return res.status(500).json({
            error: error.message || "Java compilation failed."
        });
    } finally {
        // Remove the temporary source and generated class files.
        fs.rmSync(tempDir, { recursive: true, force: true });
    }
});

// Return the most recent 10 checks.
app.get("/api/history", async (req, res) => {
    if (mongoose.connection.readyState !== 1) {
        return res.status(503).json({
            error: "MongoDB is not connected."
        });
    }

    try {
        const history = await History.find()
            .sort({ createdAt: -1 })
            .limit(10)
            .select("preview success createdAt");

        res.json({ history });
    } catch (error) {
        res.status(500).json({
            error: "Could not read history."
        });
    }
});

// Compile the Java file only. Never execute the submitted program.
function compileJava(sourcePath, workingDirectory) {
    return new Promise((resolve, reject) => {
        const child = spawn(
            "javac",
            ["-Xlint:none", sourcePath],
            {
                cwd: workingDirectory,
                timeout: 10000,
                windowsHide: true
            }
        );

        let output = "";

        child.stdout.on("data", chunk => {
            output += chunk.toString();
        });

        child.stderr.on("data", chunk => {
            output += chunk.toString();
        });

        child.on("error", error => {
            if (error.code === "ENOENT") {
                reject(
                    new Error(
                        "Java JDK not found. Install a JDK and make javac available."
                    )
                );
            } else {
                reject(error);
            }
        });

        child.on("close", exitCode => {
            resolve({
                success: exitCode === 0,
                output:
                    output ||
                    (exitCode === 0
                        ? "No compiler errors."
                        : "Compiler exited with code " + exitCode)
            });
        });
    });
}

// Convert common compiler messages into beginner-friendly explanations.
function explainCompilerOutput(output) {
    const lines = output
        .split(/\r?\n/)
        .map(line => line.trim())
        .filter(Boolean);

    const diagnostics = [];

    for (const line of lines) {
        if (/error: ';' expected/.test(line)) {
            diagnostics.push({
                title: "Missing semicolon",
                message: line,
                explanation:
                    "Java statements usually end with a semicolon (;). Add it at the end of the statement."
            });
        } else if (/incompatible types/.test(line)) {
            diagnostics.push({
                title: "Incompatible data types",
                message: line,
                explanation:
                    "The value type does not match the variable type. For example, \"20\" is text, while 20 is an integer."
            });
        } else if (/cannot find symbol/.test(line)) {
            diagnostics.push({
                title: "Name not found",
                message: line,
                explanation:
                    "Check the spelling, capitalization, declaration, and scope of the variable or method."
            });
        } else if (/class .* is public, should be declared in a file named/.test(line)) {
            diagnostics.push({
                title: "Class and filename mismatch",
                message: line,
                explanation:
                    "This starter compiles Main.java. Use public class Main for this version."
            });
        } else if (/unclosed string literal/.test(line)) {
            diagnostics.push({
                title: "Unclosed string",
                message: line,
                explanation:
                    "Check that every opening double quote has a matching closing double quote."
            });
        } else if (/illegal start|reached end of file|';' expected/.test(line)) {
            diagnostics.push({
                title: "Java syntax error",
                message: line,
                explanation:
                    "Check punctuation, braces, parentheses, and the syntax around the reported line."
            });
        }
    }

    // If a compiler message is not recognized, still show it to the user.
    if (diagnostics.length === 0 && output) {
        diagnostics.push({
            title: "Review compiler output",
            message: output.slice(0, 1800),
            explanation:
                "Use the reported line number to locate the problem and review the Java compiler message."
        });
    }

    return diagnostics.slice(0, 8);
}

// Connect to MongoDB before starting the server.
async function startServer() {
    if (!process.env.MONGODB_URI) {
        console.error("MONGODB_URI is missing from your .env file.");
        process.exit(1);
    }

    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log("MongoDB connected successfully.");

        app.listen(PORT, () => {
            console.log(`Errix backend: http://localhost:${PORT}`);
        });
    } catch (error) {
        console.error("MongoDB connection failed:", error.message);
        console.error("Check that MongoDB is running and .env is correct.");
        process.exit(1);
    }
}

startServer();